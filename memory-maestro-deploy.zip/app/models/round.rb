class Round < ApplicationRecord
  belongs_to :goal
end
