class RoundResponse < ApplicationRecord
  belongs_to :round
  belongs_to :interaction
end
