class ApplicationController < ActionController::API
  include ResponseHandler
  include ExceptionHandler
end
