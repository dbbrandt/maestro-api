class Api::UsersController < ApplicationController

  def index

  end
end
