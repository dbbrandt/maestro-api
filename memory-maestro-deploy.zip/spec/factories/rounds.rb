# spec/factories/interactions.rb
FactoryBot.define do
  factory :round do
    user { }
    goal { }
  end
end
